import React, { useState, useEffect, useCallback } from "react";

// --- DATOS (Ahora con Imágenes reales) ---
const NAV_ITEMS = ['Home', 'Blog', 'Nosotros', 'Contacto'];

const LIVES_DATA = [
  {
    title: "Luna Onírica",
    description: "Exploración profunda de sueños lúcidos y símbolos oníricos.",
    image: "https://images.unsplash.com/photo-1532431163402-3c3e29dc470b?q=80&w=800&auto=format&fit=crop", 
    youtubeUrl: "https://www.youtube.com/"
  },
  {
    title: "Geometría del Alma", 
    description: "Análisis místico del álbum LUX y su estructura sagrada.",
    image: "https://images.unsplash.com/photo-1614730341194-75c60740a2d3?q=80&w=800&auto=format&fit=crop",
    youtubeUrl: "https://www.youtube.com/"
  },
  {
    title: "I Ching Sagrado",
    description: "Encuentro dedicado al oráculo del I Ching y sus misterios.",
    image: "https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=800&auto=format&fit=crop",
    youtubeUrl: "https://www.youtube.com/"
  }
];

const BLOG_POSTS = [
  {
    title: "La Puerta Interior",
    excerpt: "Aprende a controlar tus sueños y acceder a dimensiones de consciencia.",
    tag: "Sueños",
    slug: "suenos-lucidos"
  },
  {
    title: "Sabiduría del Cambio", 
    excerpt: "Descubre cómo el oráculo milenario puede guiar tu vida diaria.",
    tag: "Oráculo",
    slug: "i-ching-sabiduria"
  },
  {
    title: "El Lenguaje Divino",
    excerpt: "La matemática que estructura el universo y nuestra psique.",
    tag: "Geometría", 
    slug: "geometria-sagrada"
  }
];

const UPCOMING_DATA = [
  { title: "Alquimia Interior", subtitle: "Transformación a través de prácticas ancestrales" },
  { title: "Taller de Sueños", subtitle: "Maestría en la exploración del mundo onírico" },
  { title: "Poesía Sagrada", subtitle: "Expresión del alma a través de la palabra" }
];

// --- ICONOS SVG (Para no usar emojis) ---
const Icons = {
  Play: () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347a1.125 1.125 0 0 1-1.667-.986V5.653Z" />
    </svg>
  ),
  ArrowRight: () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
      <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
    </svg>
  ),
  Star: () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-8 h-8">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z" />
    </svg>
  ),
  Book: () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-8 h-8">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25" />
    </svg>
  )
};

// --- COMPONENTES UI ---

const Button = ({ children, primary, href, onClick, type = "button", className = "", ...props }) => {
  const baseClasses = "inline-flex items-center justify-center py-3 px-8 text-xs uppercase font-bold tracking-widest transition-all duration-300 focus:outline-none focus:ring-1 focus:ring-offset-2";
  // Botones más elegantes: Sin bordes gruesos, uso de colores sólidos y hover suave
  const primaryClasses = "bg-stone-900 text-white hover:bg-stone-700 focus:ring-stone-900";
  const secondaryClasses = "bg-white text-stone-900 border border-stone-200 hover:border-stone-900 hover:bg-stone-50 focus:ring-stone-900";
  
  const combinedClasses = `${baseClasses} ${primary ? primaryClasses : secondaryClasses} ${className}`;
  
  if (href) {
    return <a href={href} className={combinedClasses} {...props}>{children}</a>;
  }
  return <button type={type} className={combinedClasses} onClick={onClick} {...props}>{children}</button>;
};

const LiveCard = ({ title, description, image, youtubeUrl }) => (
  <article className="group flex flex-col h-full bg-white transition-all duration-500 hover:shadow-2xl">
    {/* Contenedor de Imagen con efecto Zoom suave */}
    <div className="relative h-64 overflow-hidden bg-stone-100">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90 group-hover:opacity-100" 
      />
      <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-300" />
      
      {/* Botón Play flotante */}
      <a 
        href={youtubeUrl} 
        target="_blank" 
        rel="noopener noreferrer"
        className="absolute bottom-4 right-4 bg-white text-black p-3 rounded-full shadow-lg opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300"
        aria-label="Ver video"
      >
        <Icons.Play />
      </a>
    </div>

    <div className="flex flex-col flex-grow p-6 border-x border-b border-stone-100">
      <h3 className="font-serif text-2xl font-medium mb-3 text-stone-900">{title}</h3>
      <p className="text-stone-500 text-sm leading-relaxed mb-6 line-clamp-3">{description}</p>
    </div>
  </article>
);

const FeatureBox = ({ icon: Icon, title, subtitle }) => (
  <div className="p-8 text-center bg-stone-50/50 hover:bg-white transition-colors duration-300 border border-transparent hover:border-stone-100">
    <div className="text-stone-400 mb-4 flex justify-center"><Icon /></div>
    <h4 className="text-lg font-bold mb-2 text-stone-800 uppercase tracking-wide text-xs">{title}</h4>
    <p className="text-sm text-stone-500 leading-relaxed">{subtitle}</p>
  </div>
);

const BlogPreview = ({ title, excerpt, tag, slug }) => (
  <article className="flex flex-col h-full group cursor-pointer">
    <div className="border-l border-stone-200 pl-6 transition-all duration-300 group-hover:border-stone-900">
      <span className="text-[10px] uppercase font-bold tracking-widest text-stone-400 mb-2 block">
        {tag}
      </span>
      <h3 className="font-serif text-xl font-medium mb-3 text-stone-900 group-hover:text-stone-600 transition-colors">
        <a href={`/blog/${slug}`} className="focus:outline-none">{title}</a>
      </h3>
      <p className="text-stone-500 text-sm leading-relaxed mb-4">{excerpt}</p>
      <div className="text-xs font-bold uppercase tracking-widest text-stone-900 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -translate-x-2 group-hover:translate-x-0">
        Leer más <Icons.ArrowRight />
      </div>
    </div>
  </article>
);

const ComingSoonCard = ({ title, subtitle }) => (
  <div className="flex flex-col h-full items-center justify-center p-8 bg-white border border-stone-100 text-center">
    <div className="w-1 h-8 bg-stone-200 mb-4"></div>
    <h3 className="font-serif text-lg font-medium mb-2 text-stone-800">{title}</h3>
    <p className="text-stone-400 text-xs uppercase tracking-widest">{subtitle}</p>
  </div>
);

// --- HOOK SCROLL ---
const useScroll = (threshold = 20) => {
  const [scrolled, setScrolled] = useState(false);
  const handleScroll = useCallback(() => setScrolled(window.scrollY > threshold), [threshold]);
  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);
  return scrolled;
};

// --- APP ---
const App = () => {
  const scrolled = useScroll(20);
  const [email, setEmail] = useState("");

  const sectionClasses = "py-24 px-6 md:px-12 border-b border-stone-100";
  const containerClasses = "max-w-7xl mx-auto";
  const h2Classes = "font-serif text-4xl md:text-5xl font-medium mb-4 text-center text-stone-900";
  const subtitleClasses = "text-stone-500 mb-16 text-center max-w-xl mx-auto font-light text-sm tracking-wide uppercase";

  return (
    <div className="min-h-screen bg-white text-stone-900 font-sans">
      
      {/* Navbar Minimalista */}
      <header className={`fixed w-full top-0 z-50 transition-all duration-500 ${scrolled ? 'bg-white/95 backdrop-blur-sm border-b border-stone-100 py-4' : 'bg-transparent py-8'}`}>
        <nav className={`flex justify-between items-center ${containerClasses} px-6`}>
          <a href="#home" className={`font-serif text-xl tracking-widest font-bold uppercase z-50 transition-colors ${scrolled ? 'text-stone-900' : 'text-white'}`}>
            Sagrada Ciencia
          </a>
          <div className="hidden md:flex space-x-8">
            {NAV_ITEMS.map(item => (
              <a key={item} href={`#${item.toLowerCase()}`} className={`text-xs font-bold uppercase tracking-widest transition-colors hover:opacity-60 ${scrolled ? 'text-stone-900' : 'text-white/90'}`}>
                {item}
              </a>
            ))}
          </div>
        </nav>
      </header>

      <main>
        {/* Hero Section con Imagen de Fondo */}
        <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
          {/* Imagen de fondo oscurecida */}
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1464802686167-b939a6910659?q=80&w=2066&auto=format&fit=crop" 
              alt="Universo Místico" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40 mix-blend-multiply" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30" />
          </div>

          <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto mt-16">
            <h1 className="font-serif text-6xl md:text-8xl lg:text-9xl mb-6 tracking-tighter leading-none opacity-95">
              Sagrada<br />Ciencia
            </h1>
            <div className="w-24 h-px bg-white/50 mx-auto mb-8"></div>
            <h2 className="text-lg md:text-xl font-light tracking-wide text-white/90 max-w-2xl mx-auto mb-10">
              Jardín Cósmico de Sabiduría Mística
            </h2>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button href="#lives" className="bg-white text-black hover:bg-stone-200 border-none">
                Explorar Lives
              </Button>
              <Button href="#blog" className="bg-transparent text-white border-white hover:bg-white hover:text-black">
                Leer Blog
              </Button>
            </div>
          </div>
        </section>

        {/* Sección Lives (Imágenes y Tarjetas limpias) */}
        <section id="lives" className={sectionClasses}>
          <div className={containerClasses}>
            <h2 className={h2Classes}>Transmisiones</h2>
            <p className={subtitleClasses}>Encuentros en vivo para explorar lo invisible</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {LIVES_DATA.map((live) => (
                <LiveCard key={live.title} {...live} />
              ))}
            </div>
          </div>
        </section>

        {/* Sección Nosotros (Limpia y elegante) */}
        <section id="nosotros" className="py-24 px-6 bg-stone-50">
          <div className={`${containerClasses} max-w-5xl`}>
            <div className="text-center mb-16">
              <span className="text-xs font-bold uppercase tracking-widest text-stone-400 mb-4 block">Nuestra Esencia</span>
              <h2 className="font-serif text-3xl md:text-5xl text-stone-900 leading-tight">
                "No rechazamos la ciencia moderna,<br className="hidden md:block"/> la usamos para decodificar lo eterno."
              </h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-stone-200 border border-stone-200">
              <FeatureBox icon={Icons.Book} title="Sabiduría Antigua" subtitle="Textos sagrados y tradiciones milenarias" />
              <FeatureBox icon={Icons.Star} title="Ciencia Moderna" subtitle="Física y neurociencia aplicada" />
              <FeatureBox icon={Icons.Play} title="Transformación" subtitle="Herramientas prácticas para tu evolución" />
            </div>
          </div>
        </section>

        {/* Blog Minimalista */}
        <section id="blog" className={sectionClasses}>
          <div className={containerClasses}>
            <div className="flex flex-col md:flex-row justify-between items-end mb-16 border-b border-stone-200 pb-6">
              <div className="text-center md:text-left w-full">
                <h2 className="font-serif text-4xl text-stone-900 mb-2">Bitácora</h2>
                <p className="text-stone-500 text-sm tracking-wide uppercase">Reflexiones para el alma</p>
              </div>
              <a href="/blog" className="hidden md:block text-xs font-bold uppercase tracking-widest text-stone-900 hover:text-stone-600 whitespace-nowrap mb-1">
                Ver todo el archivo &rarr;
              </a>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {BLOG_POSTS.map((post) => (
                <BlogPreview key={post.slug} {...post} />
              ))}
            </div>
          </div>
        </section>

        {/* Próximamente */}
        <section className={sectionClasses}>
          <div className={containerClasses}>
            <h2 className="font-serif text-3xl text-center mb-12 text-stone-400 italic">Próximamente en el Jardín</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {UPCOMING_DATA.map((item) => (
                <ComingSoonCard key={item.title} {...item} />
              ))}
            </div>
          </div>
        </section>

        {/* Newsletter Limpio */}
        <section id="contacto" className="py-24 px-6 border-t border-stone-100 bg-stone-900 text-white text-center">
          <div className="max-w-2xl mx-auto">
            <h3 className="font-serif text-3xl md:text-4xl mb-6">Suscríbete al Silencio</h3>
            <p className="text-stone-400 mb-10 font-light">
              Recibe avisos de nuevos lives y artículos. Solo contenido esencial, sin ruido.
            </p>
            <form className="flex flex-col sm:flex-row gap-0 max-w-md mx-auto">
              <input 
                type="email" 
                placeholder="tu@email.com" 
                className="flex-1 p-4 bg-stone-800 border-none text-white placeholder-stone-500 focus:ring-1 focus:ring-white outline-none transition-all"
                required
              />
              <button type="submit" className="bg-white text-black px-8 py-4 text-xs font-bold uppercase tracking-widest hover:bg-stone-200 transition-colors">
                Enviar
              </button>
            </form>
          </div>
        </section>
      </main>

      {/* Footer Simple */}
      <footer className="bg-white py-12 border-t border-stone-100">
        <div className={`${containerClasses} flex flex-col md:flex-row justify-between items-center px-6 gap-6`}>
          <p className="font-serif text-xl font-bold text-stone-900">SC.</p>
          <p className="text-stone-400 text-xs">© {new Date().getFullYear()} Sagrada Ciencia.</p>
          <div className="flex gap-6 text-xs font-bold uppercase tracking-widest text-stone-500">
            <a href="#" className="hover:text-stone-900">Instagram</a>
            <a href="#" className="hover:text-stone-900">YouTube</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;